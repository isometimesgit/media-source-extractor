"use strict";

const defaultSettings = {
    whitelist: ['videosite1.com', 'videosite2.com'],
    extensions: ['avi', 'mp4', 'm3u8', 'mkv'],
    ignore: true,
    closetab: true,
    disable: false
}
